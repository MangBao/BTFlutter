class MyProfile{
  String hoTen;
  bool nam;
  String queQuan;
  DateTime ngaySinh;
  String soThich;
  String imageAssest;

  MyProfile({this.hoTen,this.nam, this.queQuan, this.ngaySinh , this.soThich, this.imageAssest});
}